import React from 'react';

class Clock extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            date: new Date(),
            //date: 0,

        };
        //setInterval(this.tick.bind(this), 1000);
     
    }    
    //after first render
    componentDidMount(){      
        //debugger; 
        this.interval = setInterval(this.tick.bind(this), 1000);
        //clearInterval(interval);
        // console.log(`${this.state.date.toString()}`); 
              
    }

    //when the component no longer gets rendered, like clicking on something that takes you to different section
    componentWillUnmount(){
        clearInterval(this.interval);
    }



    tick(){
        this.setState({
            date: new Date() 
            //date: this.date + 1
        });
    }

    render(){
        return(<h1 className="clock">{ this.state.date.toString()}</h1>);
    }
}

export default Clock;