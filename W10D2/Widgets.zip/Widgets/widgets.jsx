import React from 'react';
import ReactDOM from 'react-dom';

import Clock from './frontend/clock';



class Widget extends React.Component {


    render() {
     
        // return <Clock />;
        return(
            <>
                <Clock />
            </>
        )
    }
}


document.addEventListener("DOMContentLoaded", () => {
    const root = document.getElementById('root');
    ReactDOM.render(<Widget />, root); //we only want one of these
});


